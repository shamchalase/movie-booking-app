import { createContext } from 'react';

const ReservationContext = createContext();

export default ReservationContext;
